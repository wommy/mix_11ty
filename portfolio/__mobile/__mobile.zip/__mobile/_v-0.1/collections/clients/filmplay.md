---
title: film//play
published: true
---
the **Detroit Culture Club** contacted me 
to create a website 
for their latest event **film//play**

> [filmPlayDetroit.technomad.media](http://filmplaydetroit.technomad.media/)

i offered to create a digital respository 
a hub for their digital content and contact info
but they just wanted a description
so thats what i delivered

now that we&#39;ve gotten to know each other
i feel confident pushing for a more interactive user experience

> [a link to its facebook event](https://www.facebook.com/events/297322957126819)