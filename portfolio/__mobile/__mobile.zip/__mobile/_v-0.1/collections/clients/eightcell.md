---
title: eightcell
published: true
---
> *the most simple / efficient way*
> *to catapault your next event*
> *to the stratosphere*

operating out of chicago, they combine digital art, projection mapping, and interactive installs to make your event out of this world.  

>  [facebook.com/EightCell](https://www.facebook.com/EightCell)  

>  [youtube](https://www.youtube.com/channel/UC4GsWU1uZAa5e3G1owi9K1g)  

heres a site a made for them a couple years ago:  

>  [technomad.media/8c/](http://technomad.media/8c/)

and heres the new underconstruction site:  

>  [eightcell.tv](eightcell.tv)

###meet the team:  
truman - [ sophos visuals ]  

>  [instagram.com/sophosvisuals](https://instagram.com/sophosvisuals/)  

>  [facebook.com/sophos.visuals](https://www.facebook.com/sophos.visuals)  

bill - [ dubstompin / biww ] 

>  [instagram.com/dubstompin](instagram.com/dubstompin)

>  [soundcloud.com/dubstompin](https://soundcloud.com/dubstompin)

>  [facebook.com/bill.pilipchuk](https://www.facebook.com/bill.pilipchuk)
>  [facebook.com/DubStompinChicago](https://www.facebook.com/DubStompinChicago)
>  [facebook.com/whosbiww](https://www.facebook.com/whosbiww)

brandyn - [ mr Zpacely ] 

>  [instagram.com/zpacepix](https://instagram.com/zpacepix/)  

>  [youtube](https://www.youtube.com/channel/UCdE8MPlhBRh1po3FbHFag8A)  

>  [facebook](https://www.facebook.com/brandyn.micheal)  






