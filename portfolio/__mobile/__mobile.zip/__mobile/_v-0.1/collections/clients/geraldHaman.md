---
title: geraldHaman
published: true
---
bio

solutionpeople.com
thinkubators.com

[popcorn bulb](media#popcornBulb)