---
title: jOrris
published: true
---
> lived next to me my sophomore year at columbia
> cinematographer
> currently in australia

i designed and developed his website
which he has since personally tweaked

> [aparadi.se](http://aparadi.se)

i also acted in some videos for him
find them on my media page [here](/media#john orris originals)