---
title: wingChun
published: true
---
i&#39;ve been practicing kungfu for over a year now 
the brand is currently overhauling everything 
from fliers to the website

> current site:  [mjvingtsun.org](http://mjvingtsun.org/)  
> future site:  [vtselfdefense.com](http://vtselfdefense.com/)  