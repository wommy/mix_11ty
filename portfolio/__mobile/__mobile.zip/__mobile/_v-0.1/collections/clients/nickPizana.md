---
title: nickPizana
published: true
---
an extremely talented artist 
but also a good friend from highschool

recently has been blowing up in the detroit art scene  

> [read about his installation at the Red Bull House of Art](http://www.redbull.com/us/en/stories/1331690125340/nick-pizana-at-red-bull-house-of-art)

i created and hosted a simple website for him
which we are currently overhauling 

> [nickpizana.technomad.media](nickpizana.technomad.media)

follow him on social media:

> [facebook](https://www.facebook.com/nickypistheman)
> [instagram ( @hyper_mutant ) ](instagram.com/hyper_mutant)