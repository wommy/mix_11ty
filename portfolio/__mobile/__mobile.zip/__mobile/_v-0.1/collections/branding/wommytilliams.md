---
title: wommytilliams
published: true
---
my name has evolved numerous times throughout my life

in grade school, all my friends called me tommy
when i got to middle school, i shortened it to tom

i later realized that all my close friends called me tommy
so i switched my facebook name to tommy williams
over night, all the people i barely knew started addressing me as tommy

the newest iteration, wommytilliams came about in college
a bad breakup was causing me to be negative

people started joking that i had some type of alter ego
if tommy williams was dr jekyll, wommy was mr hyde 

"wommy" was really taking off
yet it served reference to this aspect of myself i didnt like
so i did the only thing i could and took it back

i bought <http://wommytilliams.com>

wommy tilliams' uniqueness is a double-edged sword
visually, wommy tilliams is relatively easy to get
auditorily, it sounds like a jarbled nothing 

brand wise
if you know tommy williams, wommy tilliams isn't too hard to get


if your first move  explain your brand, 
