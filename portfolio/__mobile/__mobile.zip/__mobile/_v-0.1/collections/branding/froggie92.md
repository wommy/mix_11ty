---
title: froggie92
published: true
---
froggie92 came about via [runescape](http://runescape.com)

> it was the name of the first character i created

> > i had two pet frogs
> > 9 and 2 were my two favorite numbers

i used this screen name for everything

> email: <froggie92@gmail.com>
> facebook: <https://www.facebook.com/Froggie92>
> twitter: <http://twitter.com/froggie92>
> reddit: <http://www.reddit.com/user/Froggie92/>
