---
published: true
---
<img src="assets/img/wommyBig.jpg" class="wommyImg">

# welcome to my portfolio

feel free to check out 

> [my media](/media)
> [my clients](/experience/clients)

> my experiments

> > [feed](/experiments/feed)
> > [grid](/experiments/grid)


