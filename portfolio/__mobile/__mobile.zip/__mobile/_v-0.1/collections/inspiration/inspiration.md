---
title: inspiration
published: true
---
here i want to list a few words that my design exemplifies

> simple
concise
clean
eloquent
minimal

and a few websites that have inspired me.

> <http://facsrv.cdm.depaul.edu/~cmiller/>
> - a teacher of mine, one of the first websites i encountered that put [function over form](http://ims21.net/web_form_function.htm)

> <http://itemsandthings.com/>
> -  one of my favorite music labels. their brand&#39;s dedication to minimalism is conveyed thoroughly, from their music to their web design.
> - <http://www.wanna-rework.de/>
> - - one of the musicians websites on the above label 

and a few quotes that have inspired me

[<img src="http://i.imgur.com/0MAncfi.png" width="100%">](http://i.imgur.com/0MAncfi.png)
<!-- http://www.reddit.com/r/terencemckenna/comments/32rp8t/a_quote_that_really_grabbed_me_from_terences/ -->
