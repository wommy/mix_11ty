---
title: kungfu
published: true
---
ive been practicing kungfu for over a year now

[i have a couple videos on my media page](/media#wing chun videos)

ive also been working on their website
you can see the entry on my [client page here](/experience/clients#wingChun)