---
title: biking
published: true
---
this will be my 6th year biking in chicago

check out my biking video [here](/media#create a fresh path)