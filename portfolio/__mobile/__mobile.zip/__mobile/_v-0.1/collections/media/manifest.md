---
title: inspiration
published: false
---
##media

heres a list of media i am involved in