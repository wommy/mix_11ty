---
title: john orris originals
published: true
---
i&#39;ve come to cherish the handful of [John Orris&#39;](clients#jOrris) films i acted in:

###white hot trouble
<iframe width="660" height="371" src="https://www.youtube.com/embed/6-NJz6b6XhQ?feature=oembed" frameborder="0" allowfullscreen></iframe>

###paradise shorts
<iframe src="//player.vimeo.com/video/73359740" width="660" height="371" frameborder="0" title="&quot;Paradise Shorts&quot; .01-.10" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

###naked fierce
<iframe src="//player.vimeo.com/video/106900917" width="660" height="371" frameborder="0" title="Naked - &quot;Fierce&quot;" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>