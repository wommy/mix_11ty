---
title: wing chun videos
published: true
---
###chi-sau-ing with sifu from my helmet  
<iframe width="640" height="360" src="https://www.youtube.com/embed/jO9N00johrw" frameborder="0" allowfullscreen></iframe>

###chi-sau-ing with sifu from my chest  
<iframe width="640" height="360" src="https://www.youtube.com/embed/ZYu-nuwmG3M" frameborder="0" allowfullscreen></iframe>

###chi-sau-ing with sifu from his chest  
<iframe width="640" height="360" src="https://www.youtube.com/embed/qe7le9oVrRI" frameborder="0" allowfullscreen></iframe>

###sifu going thru the first wooden dummy form  
<iframe width="640" height="360" src="https://www.youtube.com/embed/AegzO_xVyrg" frameborder="0" allowfullscreen></iframe>