---
title: create a fresh path 
published: true
---
<iframe src="https://player.vimeo.com/video/122390839" height="385" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>  

i couldn&#39;t have made this video without some help from my friends:  

[kyle roman](https://www.facebook.com/koctavioroman) helped me procure the go pro  

nick drew did the lovely editing  
visit his website @ [http://www.couchfirefilms.com/](http://www.couchfirefilms.com/)  

[brooks jones](https://www.facebook.com/BrooksJonesMusic) supplied the sweet tunes  
visit his soundcloud @ [https://soundcloud.com/tarpleybrooksjones](https://soundcloud.com/tarpleybrooksjones)  